multiview-simulation
====================

Code for simulating a multi-view acquisition including attenuation, convolution, reduced sampling and Poisson noise.

current version
===============
The current version of the source code is available on github:
https://github.com/StephanPreibisch/multiview-simulation

installation & compilation
==========================
After unzipping the archive into a new directory or preferably cloning the GIT repository (git clone https://github.com/StephanPreibisch/multiview-simulation), Maven can be used to build the source code automatically. All dependencies are managed through the pom.xml file.

The easiest way is to use Eclipse JDT (http://www.eclipse.org/jdt/) and select (Import > Existing Maven Project).

Running
=======
The main class is in the package simulation.SimulateMultiViewDataset, the PSF's are part of the distribution.